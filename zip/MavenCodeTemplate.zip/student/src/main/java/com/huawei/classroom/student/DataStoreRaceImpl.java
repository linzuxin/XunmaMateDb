package com.huawei.classroom.student;

import com.huawei.classroom.student.race.DataStoreRace;
import com.huawei.classroom.student.race.vo.Data;
import com.huawei.classroom.student.race.vo.DeltaPacket;

public class DataStoreRaceImpl implements DataStoreRace {

    @Override
    public boolean init(String dir) {
        // Delete the following line and write your code here.
        throw new RuntimeException("not implemented");
    }

    @Override
    public void deInit() {
        // Delete the following line and write your code here.
        throw new RuntimeException("not implemented");
    }

    @Override
    public void writeDeltaPacket(DeltaPacket deltaPacket) {
        // Delete the following line and write your code here.
        throw new RuntimeException("not implemented");
    }

    @Override
    public Data readDataByVersion(long key, long version) {
        // Delete the following line and write your code here.
        throw new RuntimeException("not implemented");
    }
}
